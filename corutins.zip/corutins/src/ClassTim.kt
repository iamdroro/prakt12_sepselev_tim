open class ClassTim {
    fun input():Int
    {
        println("Сколько раз вы хотите выполнить функцию")
        var a = readLine()!!.toInt()
        if(a>0)
            return a
        else println("Число должно быть положительным")
return 1

    }
    fun volt()
    {
        println("Введите первое число")
        var x= readLine()!!.toDouble()
            println("Введите второе число")
          var y= readLine()!!.toDouble()
        println("выберите что сделвть с числами: \n 1-какое число больше \n 2-сумма квадратов чисел")
        var sr= readLine()!!.toInt()
        if(sr==1)
        {
        if(x>y)
        {
            println("x=$x больше")
        }
            else println("y=$y больше")
        }
       else if (sr==2)
        {
            x=x*x+y*y
            println("сумма квадратов чисел=$x")
        }

    }
}