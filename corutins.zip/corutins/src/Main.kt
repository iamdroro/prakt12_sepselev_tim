import kotlinx.coroutines.*
suspend fun main(){
    var Class:ClassTim=ClassTim()
    var e=Class.input()
        GlobalScope.launch {
            for(i in 1..e)
            {
                println("$i раз")
                Class.volt()
            }
        }


    runBlocking { delay( 30000L) }
}